/* Ismail Ahmad Memorial Academy - School Management System + Supabase */

const SCHOOL = {
  name: "Ismail Ahmad Memorial Academy",
  motto: "Knowledge & Progress",
  address: "Women Centre, Tsohon Layi, Jahun LGA, Jigawa State",
  email: "ismailahmadacademic@yahoo.com",
  web: "https://ismailahmadacademic.ng",
  phones: ["0907 810 3435", "0803 664 4211", "0703 831 3471"]
};

let students = [
  { id: "IAMA/2024/001", name: "Amina Yusuf", class: "PRI 4", gender: "F", status: "Active", fees: "Paid", attendance: 94 },
  { id: "IAMA/2024/002", name: "Ibrahim Musa", class: "PRI 5", gender: "M", status: "Active", fees: "Partial", attendance: 88 },
  { id: "IAMA/2024/003", name: "Fatima Abubakar", class: "JS 1", gender: "F", status: "Active", fees: "Paid", attendance: 96 },
  { id: "IAMA/2024/004", name: "Sani Mohammed", class: "PRI 3", gender: "M", status: "Active", fees: "Outstanding", attendance: 79 },
  { id: "IAMA/2024/005", name: "Hauwa Aliyu", class: "PRI 6", gender: "F", status: "Active", fees: "Paid", attendance: 91 },
  { id: "IAMA/2024/006", name: "Usman Bello", class: "JS 2", gender: "M", status: "Active", fees: "Paid", attendance: 85 },
  { id: "IAMA/2025/007", name: "Zainab Suleiman", class: "Nursery", gender: "F", status: "Active", fees: "Paid", attendance: 98 },
  { id: "IAMA/2024/008", name: "Abdullahi Garba", class: "PRI 1", gender: "M", status: "Active", fees: "Partial", attendance: 82 },
];

let staff = [
  { id: "STF001", name: "Mallam Kabiru Hassan", role: "Principal", subject: "Admin", phone: "0803 xxx xxxx" },
  { id: "STF002", name: "Mrs. Aisha Mohammed", role: "Admin Officer", subject: "Admin", phone: "0806 xxx xxxx" },
  { id: "STF003", name: "Mr. Yusuf Ibrahim", role: "Teacher", subject: "Mathematics", phone: "0703 xxx xxxx" },
  { id: "STF004", name: "Malama Maryam Sani", role: "Teacher", subject: "English", phone: "0812 xxx xxxx" },
  { id: "STF005", name: "Mr. Bashir Ahmed", role: "Teacher", subject: "Basic Science", phone: "0809 xxx xxxx" },
  { id: "STF006", name: "Mrs. Rabi'u Fatima", role: "Teacher", subject: "Islamic Studies", phone: "0701 xxx xxxx" },
];

let notices = [
  { title: "End of Term Examination Timetable Released", date: "20 Aug 2026", urgent: true, body: "Exams begin 1st September. Collect timetable from class teachers." },
  { title: "PTA Meeting – All Parents Invited", date: "18 Aug 2026", urgent: false, body: "Saturday 30th August, 10:00 AM at the school hall." },
  { title: "School Fees Reminder – 2nd Term", date: "15 Aug 2026", urgent: true, body: "Outstanding fees should be cleared before report card collection." },
  { title: "New Junior Secondary Section Opening Soon", date: "10 Aug 2026", urgent: false, body: "Application for JSS 1–3 ongoing. Contact the admin office." },
];

let feesRecords = [
  { student: "Amina Yusuf", class: "PRI 4", term: "2nd", total: 25000, paid: 25000, balance: 0 },
  { student: "Ibrahim Musa", class: "PRI 5", term: "2nd", total: 25000, paid: 15000, balance: 10000 },
  { student: "Fatima Abubakar", class: "JS 1", term: "2nd", total: 30000, paid: 30000, balance: 0 },
  { student: "Sani Mohammed", class: "PRI 3", term: "2nd", total: 25000, paid: 0, balance: 25000 },
  { student: "Hauwa Aliyu", class: "PRI 6", term: "2nd", total: 25000, paid: 25000, balance: 0 },
];

const results = [
  { student: "Amina Yusuf", class: "PRI 4", eng: 78, math: 82, sci: 75, avg: 78.3, grade: "A", pos: 3 },
  { student: "Ibrahim Musa", class: "PRI 5", eng: 65, math: 70, sci: 68, avg: 67.7, grade: "B", pos: 8 },
  { student: "Fatima Abubakar", class: "JS 1", eng: 88, math: 91, sci: 85, avg: 88.0, grade: "A", pos: 1 },
  { student: "Hauwa Aliyu", class: "PRI 6", eng: 72, math: 68, sci: 74, avg: 71.3, grade: "B", pos: 5 },
];

let useSupabase = false;

function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  const sec = document.getElementById(id);
  if (sec) sec.classList.add('active');
  const link = document.querySelector('[data-section="' + id + '"]');
  if (link) link.classList.add('active');
  document.getElementById('navLinks')?.classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

function setDbBadge(status) {
  const el = document.getElementById('dbStatus');
  if (!el) return;
  if (status === 'online') {
    el.textContent = '● Cloud connected';
    el.style.color = '#86efac';
  } else if (status === 'error') {
    el.textContent = '● Cloud error (demo mode)';
    el.style.color = '#fca5a5';
  } else {
    el.textContent = '● Offline demo';
    el.style.color = '#fdba74';
  }
}

async function loadFromSupabase() {
  const sb = window.getSupabase && window.getSupabase();
  if (!sb) {
    setDbBadge('offline');
    return false;
  }
  try {
    const [stuRes, staffRes, noticeRes, feeRes] = await Promise.all([
      sb.from('students').select('*').order('created_at', { ascending: false }),
      sb.from('staff').select('*').order('full_name'),
      sb.from('notices').select('*').order('created_at', { ascending: false }),
      sb.from('fee_payments').select('*').order('created_at', { ascending: false }),
    ]);

    if (stuRes.error) throw stuRes.error;

    if (stuRes.data && stuRes.data.length) {
      students = stuRes.data.map(s => ({
        uuid: s.id,
        id: s.admission_no,
        name: s.full_name,
        class: s.class_name,
        gender: s.gender || 'M',
        status: s.status || 'Active',
        fees: s.fees_status || 'Outstanding',
        attendance: 90,
        guardian: s.guardian_name,
        phone: s.guardian_phone
      }));
    }
    if (staffRes.data && !staffRes.error && staffRes.data.length) {
      staff = staffRes.data.map(s => ({
        id: s.staff_id || s.id,
        name: s.full_name,
        role: s.role || '',
        subject: s.subject || '',
        phone: s.phone || ''
      }));
    }
    if (noticeRes.data && !noticeRes.error && noticeRes.data.length) {
      notices = noticeRes.data.map(n => ({
        title: n.title,
        body: n.body,
        urgent: !!n.is_urgent,
        date: n.created_at ? new Date(n.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : ''
      }));
    }
    if (feeRes.data && !feeRes.error && feeRes.data.length) {
      feesRecords = feeRes.data.map(f => ({
        student: f.student_name,
        class: f.class_name,
        term: f.term || '2nd',
        total: Number(f.total_amount) || 0,
        paid: Number(f.amount_paid) || 0,
        balance: Number(f.balance) || 0
      }));
    }

    useSupabase = true;
    setDbBadge('online');
    toast('Connected to cloud database');
    return true;
  } catch (err) {
    console.error('Supabase load error:', err);
    setDbBadge('error');
    toast('Cloud unavailable — using demo data. Run SQL schema in Supabase.');
    return false;
  }
}

function login(e) {
  e.preventDefault();
  const user = document.getElementById('loginUser').value.trim();
  const pass = document.getElementById('loginPass').value;
  if (user && pass) {
    document.getElementById('loginOverlay').style.display = 'none';
    document.getElementById('app').style.display = 'block';
    document.getElementById('userLabel').textContent = user;
    toast('Welcome, ' + user + '!');
    showSection('dashboard');
    refreshAll();
  } else {
    toast('Please enter username and password');
  }
}

function logout() {
  document.getElementById('loginOverlay').style.display = 'flex';
  document.getElementById('app').style.display = 'none';
  document.getElementById('loginUser').value = '';
  document.getElementById('loginPass').value = '';
}

function refreshAll() {
  renderStudents();
  renderStaff();
  renderNotices();
  renderFees();
  renderResults();
  renderAttendance();
  updateStats();
  syncDashNotices();
}

function renderStudents(filter) {
  filter = filter || '';
  const q = filter.toLowerCase();
  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(q) || String(s.id).toLowerCase().includes(q) || s.class.toLowerCase().includes(q)
  );
  const tbody = document.getElementById('studentTableBody');
  if (!tbody) return;
  tbody.innerHTML = filtered.map(s => {
    const feeBadge = s.fees === 'Paid' ? 'badge-green' : s.fees === 'Partial' ? 'badge-orange' : 'badge-red';
    return '<tr><td>' + s.id + '</td><td><strong>' + s.name + '</strong></td><td>' + s.class + '</td><td>' + s.gender +
      '</td><td><span class="badge badge-green">' + s.status + '</span></td><td><span class="badge ' + feeBadge + '">' + s.fees +
      '</span></td><td>' + (s.attendance || '—') + '%</td><td><button class="btn btn-sm btn-blue" onclick="toast(\'View: ' + s.name + '\')">View</button></td></tr>';
  }).join('') || '<tr><td colspan="8">No students found</td></tr>';
}

function renderStaff() {
  const tbody = document.getElementById('staffTableBody');
  if (!tbody) return;
  tbody.innerHTML = staff.map(s => '<tr><td>' + s.id + '</td><td><strong>' + s.name + '</strong></td><td>' + s.role +
    '</td><td>' + s.subject + '</td><td>' + s.phone + '</td></tr>').join('');
}

function renderNotices() {
  const el = document.getElementById('noticesList');
  if (!el) return;
  el.innerHTML = notices.map(n =>
    '<div class="notice-item ' + (n.urgent ? 'urgent' : '') + '"><strong>' + n.title +
    '</strong><p style="margin-top:0.35rem;font-size:0.9rem">' + n.body +
    '</p><div class="meta">' + (n.date || '') + (n.urgent ? ' · URGENT' : '') + '</div></div>'
  ).join('') || '<p>No notices yet</p>';
  syncDashNotices();
}

function syncDashNotices() {
  const list = document.getElementById('noticesList');
  const dash = document.getElementById('noticesListDash');
  if (list && dash) dash.innerHTML = list.innerHTML;
}

function renderFees() {
  const tbody = document.getElementById('feesTableBody');
  if (!tbody) return;
  tbody.innerHTML = feesRecords.map(f => {
    const badge = f.balance === 0 ? 'badge-green' : f.paid > 0 ? 'badge-orange' : 'badge-red';
    const status = f.balance === 0 ? 'Paid' : f.paid > 0 ? 'Partial' : 'Outstanding';
    return '<tr><td>' + f.student + '</td><td>' + f.class + '</td><td>' + f.term +
      '</td><td>₦' + Number(f.total).toLocaleString() + '</td><td>₦' + Number(f.paid).toLocaleString() +
      '</td><td>₦' + Number(f.balance).toLocaleString() + '</td><td><span class="badge ' + badge + '">' + status + '</span></td></tr>';
  }).join('');
}

function renderResults() {
  const tbody = document.getElementById('resultsTableBody');
  if (!tbody) return;
  tbody.innerHTML = results.map(r => '<tr><td>' + r.student + '</td><td>' + r.class + '</td><td>' + r.eng +
    '</td><td>' + r.math + '</td><td>' + r.sci + '</td><td><strong>' + r.avg +
    '</strong></td><td><span class="badge badge-blue">' + r.grade + '</span></td><td>' + r.pos + '</td></tr>').join('');
}

function renderAttendance() {
  const grid = document.getElementById('attendanceGrid');
  if (!grid) return;
  grid.innerHTML = students.map(s => {
    const status = (s.attendance || 90) >= 90 ? 'present' : (s.attendance || 90) >= 80 ? 'late' : 'absent';
    const label = status === 'present' ? 'Present' : status === 'late' ? 'Late' : 'Absent';
    return '<div class="att-cell ' + status + '" onclick="cycleAttendance(this)" data-name="' + s.name +
      '" data-id="' + (s.uuid || s.id) + '"><strong>' + s.name.split(' ')[0] +
      '</strong><br><small>' + s.class + '</small><br><span>' + label + '</span></div>';
  }).join('');
}

function cycleAttendance(el) {
  if (el.classList.contains('present')) {
    el.classList.replace('present', 'late');
    el.querySelector('span').textContent = 'Late';
  } else if (el.classList.contains('late')) {
    el.classList.replace('late', 'absent');
    el.querySelector('span').textContent = 'Absent';
  } else {
    el.classList.remove('absent');
    el.classList.add('present');
    el.querySelector('span').textContent = 'Present';
  }
  toast('Attendance updated: ' + el.dataset.name);
}

function markAllPresent() {
  document.querySelectorAll('.att-cell').forEach(el => {
    el.classList.remove('absent', 'late');
    el.classList.add('present');
    el.querySelector('span').textContent = 'Present';
  });
  toast('All marked Present');
}

async function saveAttendance() {
  const sb = window.getSupabase && window.getSupabase();
  const cells = document.querySelectorAll('.att-cell');
  const date = document.getElementById('attDate')?.value || new Date().toISOString().slice(0, 10);

  if (sb && useSupabase) {
    try {
      for (const el of cells) {
        const status = el.classList.contains('present') ? 'Present' : el.classList.contains('late') ? 'Late' : 'Absent';
        const name = el.dataset.name;
        const stu = students.find(s => s.name === name);
        if (stu && stu.uuid) {
          await sb.from('attendance').upsert({
            student_id: stu.uuid,
            attendance_date: date,
            status: status,
            class_name: stu.class,
            marked_by: document.getElementById('userLabel')?.textContent || 'Staff'
          }, { onConflict: 'student_id,attendance_date' });
        }
      }
      toast('Attendance saved to cloud!');
      return;
    } catch (err) {
      console.error(err);
      toast('Cloud save failed — saved locally');
    }
  }
  toast('Attendance saved!');
}

async function addNotice(e) {
  e.preventDefault();
  const title = document.getElementById('noticeTitle').value;
  const body = document.getElementById('noticeBody').value;
  const urgent = document.getElementById('noticeUrgent').checked;
  if (!title || !body) return toast('Fill all fields');

  const notice = {
    title: title,
    body: body,
    date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    urgent: urgent
  };

  const sb = window.getSupabase && window.getSupabase();
  if (sb && useSupabase) {
    try {
      const { error } = await sb.from('notices').insert({
        title: title,
        body: body,
        is_urgent: urgent,
        published_by: document.getElementById('userLabel')?.textContent || 'Admin'
      });
      if (error) throw error;
      toast('Notice published to cloud!');
    } catch (err) {
      console.error(err);
      toast('Cloud error — saved locally');
    }
  } else {
    toast('Notice published!');
  }

  notices.unshift(notice);
  renderNotices();
  e.target.reset();
}

async function recordFee(e) {
  e.preventDefault();
  const form = e.target;
  const name = form.querySelector('input[type="text"]').value;
  const amount = Number(form.querySelector('input[type="number"]').value) || 0;
  const selects = form.querySelectorAll('select');
  const cls = selects[0]?.value || '';
  const mode = selects[1]?.value || 'Cash';

  const sb = window.getSupabase && window.getSupabase();
  if (sb && useSupabase) {
    try {
      await sb.from('fee_payments').insert({
        student_name: name,
        class_name: cls,
        term: '2nd',
        total_amount: amount,
        amount_paid: amount,
        balance: 0,
        payment_mode: mode
      });
      toast('Payment saved to cloud!');
      await loadFromSupabase();
      renderFees();
      updateStats();
    } catch (err) {
      console.error(err);
      toast('Cloud error — recorded locally');
    }
  } else {
    toast('Fee payment recorded successfully!');
  }
  form.reset();
}

async function admitStudent(e) {
  e.preventDefault();
  const name = document.getElementById('admitName').value;
  const cls = document.getElementById('admitClass').value;
  const gender = document.getElementById('admitGender').value || 'M';
  if (!name || !cls) return toast('Fill required fields');

  const id = 'IAMA/2026/' + String(students.length + 1).padStart(3, '0');

  const sb = window.getSupabase && window.getSupabase();
  if (sb && useSupabase) {
    try {
      const { error } = await sb.from('students').insert({
        admission_no: id,
        full_name: name,
        class_name: cls,
        gender: gender,
        status: 'Active',
        fees_status: 'Outstanding'
      });
      if (error) throw error;
      toast('Student saved to cloud: ' + name);
      await loadFromSupabase();
      refreshAll();
      e.target.reset();
      showSection('students');
      return;
    } catch (err) {
      console.error(err);
      toast('Cloud error — saved locally');
    }
  }

  students.push({ id: id, name: name, class: cls, gender: gender, status: 'Active', fees: 'Outstanding', attendance: 100 });
  renderStudents();
  updateStats();
  e.target.reset();
  toast('Student admitted: ' + name);
  showSection('students');
}

function updateStats() {
  const el = function(id) { return document.getElementById(id); };
  if (el('statStudents')) el('statStudents').textContent = students.length;
  if (el('statStaff')) el('statStaff').textContent = staff.length;
  if (el('statPaid')) el('statPaid').textContent = feesRecords.filter(f => f.balance === 0).length;
  if (el('statOutstanding')) el('statOutstanding').textContent = feesRecords.filter(f => f.balance > 0).length;
}

function initCalendar() {
  const days = document.getElementById('calDays');
  if (!days) return;
  const today = new Date().getDate();
  let html = ['Su','Mo','Tu','We','Th','Fr','Sa'].map(function(d) {
    return '<div class="cal-day" style="font-weight:700;background:transparent">' + d + '</div>';
  }).join('');
  for (let i = 0; i < 6; i++) html += '<div class="cal-day" style="visibility:hidden">-</div>';
  for (let d = 1; d <= 31; d++) {
    let cls = 'cal-day';
    if (d === today) cls += ' today';
    if ([1, 15, 30].indexOf(d) >= 0) cls += ' event';
    html += '<div class="' + cls + '">' + d + '</div>';
  }
  days.innerHTML = html;
}

document.addEventListener('DOMContentLoaded', async function() {
  if (window.initSupabase) window.initSupabase();
  await loadFromSupabase();
  refreshAll();
  initCalendar();
  document.getElementById('studentSearch')?.addEventListener('input', function(e) { renderStudents(e.target.value); });
  const d = document.getElementById('attDate');
  if (d) d.valueAsDate = new Date();
});

/* ========== MARKS / GRADING / DENSE RANK ========== */

const SUBJECTS = ['eng','maths','sci','soc','irs','hausa','comp'];
const SUBJECT_LABELS = { eng:'English', maths:'Maths', sci:'Science', soc:'Social', irs:'IRS/CRS', hausa:'Hausa', comp:'Computer' };

// Grade from average
function gradeFromAverage(avg) {
  if (avg >= 70) return 'A';
  if (avg >= 60) return 'B';
  if (avg >= 50) return 'C';
  if (avg >= 40) return 'D';
  if (avg >= 30) return 'E';
  return 'F';
}

/**
 * Dense ranking: ties share the same position, next rank does NOT skip.
 * Example: scores 90,90,90,80,80,70 → positions 1,1,1,2,2,3
 */
function denseRankByTotal(rows) {
  // rows: [{ total, ... }]
  const sorted = rows.slice().sort((a, b) => b.total - a.total);
  let rank = 0;
  let prevTotal = null;
  const posMap = {}; // index in original → position

  sorted.forEach((row, i) => {
    if (prevTotal === null || row.total !== prevTotal) {
      rank += 1; // dense: only increase by 1 even after ties
      prevTotal = row.total;
    }
    posMap[row._idx] = rank;
  });
  return posMap;
}

function checkMarksRole() {
  const role = document.getElementById('marksRole')?.value;
  const lock = document.getElementById('marksLockMsg');
  const sheet = document.getElementById('marksSheetWrap');
  const canEdit = role === 'class_master';

  if (!role) {
    if (lock) lock.style.display = 'none';
    if (sheet) sheet.style.display = 'none';
    return;
  }
  if (lock) lock.style.display = canEdit ? 'none' : 'block';
  if (sheet) {
    // still show sheet for view, but disable inputs if not class_master
    if (document.getElementById('marksClass')?.value) {
      sheet.style.display = 'block';
      setMarksEditable(canEdit);
    }
  }
  loadMarksSheet();
}

function setMarksEditable(editable) {
  document.querySelectorAll('#marksTableBody input[data-subj]').forEach(inp => {
    inp.disabled = !editable;
    inp.style.background = editable ? '#fff' : '#f1f5f9';
  });
  const btnCalc = document.getElementById('btnCalcRanks');
  const btnSave = document.getElementById('btnSaveMarks');
  if (btnCalc) btnCalc.style.display = editable ? 'inline-block' : 'none';
  if (btnSave) btnSave.style.display = editable ? 'inline-block' : 'none';
}

function loadMarksSheet() {
  const cls = document.getElementById('marksClass')?.value;
  const role = document.getElementById('marksRole')?.value;
  const sheet = document.getElementById('marksSheetWrap');
  if (!cls || !role) {
    if (sheet) sheet.style.display = 'none';
    return;
  }
  if (sheet) sheet.style.display = 'block';

  // Students in this class (from loaded students list)
  let classStudents = students.filter(s => s.class === cls);
  if (classStudents.length === 0) {
    // create empty rows from sample if none match
    classStudents = [
      { id: '—', name: 'Student 1' },
      { id: '—', name: 'Student 2' },
      { id: '—', name: 'Student 3' },
    ];
  }

  const tbody = document.getElementById('marksTableBody');
  tbody.innerHTML = classStudents.map((s, i) => {
    return '<tr data-row="' + i + '">' +
      '<td><input type="text" value="' + s.name + '" data-field="name" style="width:120px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" /></td>' +
      '<td><input type="text" value="' + s.id + '" data-field="adm" style="width:100px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" /></td>' +
      SUBJECTS.map(sub =>
        '<td><input type="number" min="0" max="100" step="0.5" value="0" data-subj="' + sub +
        '" style="width:58px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" oninput="onMarkInput(this)" /></td>'
      ).join('') +
      '<td data-total="1"><strong>0</strong></td>' +
      '<td data-avg="1"><strong>0</strong></td>' +
      '<td data-grade="1"><span class="badge badge-blue">F</span></td>' +
      '<td data-pos="1"><strong>—</strong></td>' +
      '</tr>';
  }).join('');

  setMarksEditable(role === 'class_master');
}

function onMarkInput(inp) {
  const row = inp.closest('tr');
  recalcRow(row);
  // live re-rank optional on every keystroke can be heavy; user clicks Calculate
}

function recalcRow(row) {
  let total = 0;
  let count = 0;
  row.querySelectorAll('input[data-subj]').forEach(inp => {
    const v = parseFloat(inp.value);
    if (!isNaN(v)) { total += v; count++; }
  });
  const avg = count ? total / SUBJECTS.length : 0;
  const grade = gradeFromAverage(avg);
  row.querySelector('[data-total]').innerHTML = '<strong>' + total.toFixed(1) + '</strong>';
  row.querySelector('[data-avg]').innerHTML = '<strong>' + avg.toFixed(2) + '</strong>';
  row.querySelector('[data-grade]').innerHTML = '<span class="badge badge-blue">' + grade + '</span>';
  row.dataset.total = total;
  row.dataset.avg = avg;
  row.dataset.grade = grade;
}

function recalculateAllMarks() {
  const role = document.getElementById('marksRole')?.value;
  if (role !== 'class_master') {
    toast('Only Class Master can calculate and save marks');
    return;
  }
  const rows = Array.from(document.querySelectorAll('#marksTableBody tr'));
  const data = rows.map((row, idx) => {
    recalcRow(row);
    return { _idx: idx, total: parseFloat(row.dataset.total) || 0, row: row };
  });

  const posMap = denseRankByTotal(data);
  data.forEach(d => {
    const pos = posMap[d._idx];
    d.row.querySelector('[data-pos]').innerHTML = '<strong>' + pos + '</strong>';
    d.row.dataset.pos = pos;
  });

  // Explain ties in toast
  const totals = data.map(d => d.total);
  const hasTies = totals.some((t, i) => totals.indexOf(t) !== i);
  toast(hasTies
    ? 'Calculated! Tied scores share position (no skip). e.g. 1,1,1 then 2…'
    : 'Grades, averages and positions calculated');
}

function addMarksRow() {
  if (document.getElementById('marksRole')?.value !== 'class_master') {
    toast('Only Class Master can add rows');
    return;
  }
  const tbody = document.getElementById('marksTableBody');
  const i = tbody.querySelectorAll('tr').length;
  const tr = document.createElement('tr');
  tr.dataset.row = i;
  tr.innerHTML =
    '<td><input type="text" value="" data-field="name" placeholder="Name" style="width:120px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" /></td>' +
    '<td><input type="text" value="" data-field="adm" placeholder="Adm No" style="width:100px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" /></td>' +
    SUBJECTS.map(sub =>
      '<td><input type="number" min="0" max="100" step="0.5" value="0" data-subj="' + sub +
      '" style="width:58px;padding:0.3rem;border:1px solid #cbd5e1;border-radius:4px" oninput="onMarkInput(this)" /></td>'
    ).join('') +
    '<td data-total="1"><strong>0</strong></td>' +
    '<td data-avg="1"><strong>0</strong></td>' +
    '<td data-grade="1"><span class="badge badge-blue">F</span></td>' +
    '<td data-pos="1"><strong>—</strong></td>';
  tbody.appendChild(tr);
}

async function saveAllMarks() {
  const role = document.getElementById('marksRole')?.value;
  if (role !== 'class_master') {
    toast('Only Class Master can save marks');
    return;
  }
  recalculateAllMarks();

  const cls = document.getElementById('marksClass')?.value;
  const term = document.getElementById('marksTerm')?.value;
  const session = document.getElementById('marksSession')?.value;
  const rows = Array.from(document.querySelectorAll('#marksTableBody tr'));
  const payload = rows.map(row => {
    const marks = {};
    SUBJECTS.forEach(sub => {
      marks[sub] = parseFloat(row.querySelector('input[data-subj="' + sub + '"]')?.value) || 0;
    });
    return {
      student_name: row.querySelector('[data-field="name"]')?.value || '',
      admission_no: row.querySelector('[data-field="adm"]')?.value || '',
      class_name: cls,
      term: term,
      session_year: session,
      english: marks.eng,
      maths: marks.maths,
      science: marks.sci,
      social: marks.soc,
      islamic_crs: marks.irs,
      hausa: marks.hausa,
      computer: marks.comp,
      total: parseFloat(row.dataset.total) || 0,
      average: parseFloat(row.dataset.avg) || 0,
      grade: row.dataset.grade || 'F',
      position: parseInt(row.dataset.pos, 10) || null,
      entered_by: document.getElementById('userLabel')?.textContent || 'Class Master'
    };
  }).filter(r => r.student_name);

  // Update local results preview
  window._lastMarksPayload = payload;

  const sb = window.getSupabase && window.getSupabase();
  if (sb && useSupabase) {
    try {
      for (const row of payload) {
        await sb.from('class_results').upsert(row, {
          onConflict: 'admission_no,class_name,term,session_year'
        });
      }
      toast('Marks saved to cloud (' + payload.length + ' students)');
      return;
    } catch (err) {
      console.error(err);
      toast('Cloud save failed — kept in session. Run class_results SQL if needed.');
    }
  }
  toast('Marks saved locally (' + payload.length + ' students). Click Reports to generate.');
}

function generateClassReport() {
  const cls = document.getElementById('repClass')?.value;
  const term = document.getElementById('repTerm')?.value;
  let data = window._lastMarksPayload || [];
  data = data.filter(r => r.class_name === cls || !cls);
  if (!data.length) {
    // fallback demo
    data = [
      { student_name: 'Fatima Abubakar', admission_no: 'IAMA/2024/003', total: 264, average: 88, grade: 'A', position: 1, english: 88, maths: 91, science: 85 },
      { student_name: 'Amina Yusuf', admission_no: 'IAMA/2024/001', total: 235, average: 78.3, grade: 'A', position: 2, english: 78, maths: 82, science: 75 },
      { student_name: 'Hauwa Aliyu', admission_no: 'IAMA/2024/005', total: 214, average: 71.3, grade: 'B', position: 3, english: 72, maths: 68, science: 74 },
    ];
  }
  // ensure dense rank
  data = data.map((r, i) => ({ ...r, _idx: i, total: Number(r.total) || 0 }));
  const posMap = denseRankByTotal(data);
  data.forEach(r => { r.position = posMap[r._idx]; });
  data.sort((a, b) => a.position - b.position);

  let html = '<div class="table-wrap"><table><thead><tr><th>Pos</th><th>Name</th><th>Adm No</th><th>Total</th><th>Average</th><th>Grade</th></tr></thead><tbody>';
  data.forEach(r => {
    html += '<tr><td><strong>' + r.position + '</strong></td><td>' + r.student_name + '</td><td>' + (r.admission_no || '') +
      '</td><td>' + r.total + '</td><td>' + Number(r.average).toFixed(2) + '</td><td><span class="badge badge-blue">' + r.grade + '</span></td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p style="font-size:0.8rem;color:#64748b;margin-top:0.5rem">Class: ' + cls + ' · Term: ' + term +
    ' · Dense rank (ties share position, no skip)</p>';

  document.getElementById('classReportOut').innerHTML = html;
  showReportPreview('Class Result Sheet — ' + cls + ' (' + term + ' Term)', html);
}

function generateStudentReport() {
  const name = (document.getElementById('repStudentName')?.value || '').trim().toLowerCase();
  let data = window._lastMarksPayload || [];
  let row = data.find(r => (r.student_name || '').toLowerCase().includes(name));
  if (!row && name) {
    row = {
      student_name: document.getElementById('repStudentName').value,
      class_name: 'PRI 4', term: '2nd', session_year: '2025/2026',
      english: 78, maths: 82, science: 75, social: 70, islamic_crs: 80, hausa: 72, computer: 68,
      total: 525, average: 75, grade: 'A', position: 3
    };
  }
  if (!row) return toast('Enter a student name (or save marks first)');

  const subjects = [
    ['English', row.english], ['Mathematics', row.maths], ['Basic Science', row.science],
    ['Social Studies', row.social], ['IRS / CRS', row.islamic_crs], ['Hausa', row.hausa], ['Computer', row.computer]
  ];
  let html = '<p><strong>' + row.student_name + '</strong> · ' + (row.class_name || '') +
    ' · ' + (row.term || '') + ' Term · ' + (row.session_year || '') + '</p>';
  html += '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Score</th></tr></thead><tbody>';
  subjects.forEach(([n, s]) => {
    html += '<tr><td>' + n + '</td><td>' + (s != null ? s : '—') + '</td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<p style="margin-top:0.75rem"><strong>Total:</strong> ' + row.total +
    ' &nbsp; <strong>Average:</strong> ' + Number(row.average).toFixed(2) +
    ' &nbsp; <strong>Grade:</strong> ' + row.grade +
    ' &nbsp; <strong>Position:</strong> ' + row.position + '</p>';

  document.getElementById('studentReportOut').innerHTML = html;
  showReportPreview('Report Card — ' + row.student_name, html);
}

function showReportPreview(title, bodyHtml) {
  const box = document.getElementById('reportPreview');
  const body = document.getElementById('reportPreviewBody');
  if (!box || !body) return;
  box.style.display = 'block';
  body.innerHTML = '<h3 style="color:#062d5c">' + title + '</h3>' +
    '<p style="font-size:0.85rem;color:#64748b">Ismail Ahmad Memorial Academy · Knowledge &amp; Progress</p>' + bodyHtml;
}
