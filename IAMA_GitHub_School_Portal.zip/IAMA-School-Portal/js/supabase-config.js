// Supabase configuration - Ismail Ahmad Memorial Academy
const SUPABASE_URL = 'https://sahfqmjabdlieiwbmvoi.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Nd-Yocjj36L8N69h1B98TQ_tFLf';

// Create client (loaded after supabase-js CDN)
let supabaseClient = null;

function initSupabase() {
  if (typeof window.supabase !== 'undefined' && window.supabase.createClient) {
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    console.log('Supabase connected:', SUPABASE_URL);
    return true;
  }
  console.warn('Supabase SDK not loaded — using offline demo data');
  return false;
}

window.SUPABASE_URL = SUPABASE_URL;
window.SUPABASE_ANON_KEY = SUPABASE_ANON_KEY;
window.getSupabase = () => supabaseClient;
window.initSupabase = initSupabase;
