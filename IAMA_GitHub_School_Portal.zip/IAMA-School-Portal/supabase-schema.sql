-- ============================================================
-- Ismail Ahmad Memorial Academy - Supabase Database Schema
-- Run this in: Supabase Dashboard → SQL Editor → New query → Run
-- ============================================================

-- Students
CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admission_no TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  class_name TEXT NOT NULL,
  gender TEXT CHECK (gender IN ('M', 'F')),
  date_of_birth DATE,
  guardian_name TEXT,
  guardian_phone TEXT,
  address TEXT,
  status TEXT DEFAULT 'Active',
  fees_status TEXT DEFAULT 'Outstanding',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Staff
CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id TEXT UNIQUE,
  full_name TEXT NOT NULL,
  role TEXT,
  subject TEXT,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Attendance
CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  attendance_date DATE NOT NULL DEFAULT CURRENT_DATE,
  status TEXT CHECK (status IN ('Present', 'Absent', 'Late')) DEFAULT 'Present',
  class_name TEXT,
  marked_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, attendance_date)
);

-- Fees payments
CREATE TABLE IF NOT EXISTS fee_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE SET NULL,
  student_name TEXT,
  class_name TEXT,
  term TEXT,
  total_amount NUMERIC(12,2) DEFAULT 0,
  amount_paid NUMERIC(12,2) DEFAULT 0,
  balance NUMERIC(12,2) DEFAULT 0,
  payment_mode TEXT,
  receipt_no TEXT,
  payment_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notices
CREATE TABLE IF NOT EXISTS notices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  is_urgent BOOLEAN DEFAULT FALSE,
  published_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Results
CREATE TABLE IF NOT EXISTS results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  student_name TEXT,
  class_name TEXT,
  term TEXT,
  session_year TEXT,
  english NUMERIC(5,1),
  maths NUMERIC(5,1),
  science NUMERIC(5,1),
  average NUMERIC(5,1),
  grade TEXT,
  position INT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (optional - open for demo with anon key)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE fee_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE results ENABLE ROW LEVEL SECURITY;

-- Policies: allow anon key full access for school portal demo
-- (Tighten these later with auth.uid() rules for production)
CREATE POLICY "Allow all on students" ON students FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on staff" ON staff FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on attendance" ON attendance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on fee_payments" ON fee_payments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on notices" ON notices FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on results" ON results FOR ALL USING (true) WITH CHECK (true);

-- Sample seed data
INSERT INTO students (admission_no, full_name, class_name, gender, guardian_name, guardian_phone, fees_status) VALUES
('IAMA/2024/001', 'Amina Yusuf', 'PRI 4', 'F', 'Yusuf Ibrahim', '08031234567', 'Paid'),
('IAMA/2024/002', 'Ibrahim Musa', 'PRI 5', 'M', 'Musa Ali', '08061234567', 'Partial'),
('IAMA/2024/003', 'Fatima Abubakar', 'JS 1', 'F', 'Abubakar Sani', '07031234567', 'Paid'),
('IAMA/2024/004', 'Sani Mohammed', 'PRI 3', 'M', 'Mohammed Bello', '08121234567', 'Outstanding'),
('IAMA/2024/005', 'Hauwa Aliyu', 'PRI 6', 'F', 'Aliyu Hassan', '08091234567', 'Paid'),
('IAMA/2024/006', 'Usman Bello', 'JS 2', 'M', 'Bello Usman', '07011234567', 'Paid'),
('IAMA/2025/007', 'Zainab Suleiman', 'Nursery', 'F', 'Suleiman Ahmed', '08051234567', 'Paid'),
('IAMA/2024/008', 'Abdullahi Garba', 'PRI 1', 'M', 'Garba Abdullahi', '08161234567', 'Partial')
ON CONFLICT (admission_no) DO NOTHING;

INSERT INTO staff (staff_id, full_name, role, subject, phone) VALUES
('STF001', 'Mallam Kabiru Hassan', 'Principal', 'Admin', '08030000001'),
('STF002', 'Mrs. Aisha Mohammed', 'Admin Officer', 'Admin', '08060000002'),
('STF003', 'Mr. Yusuf Ibrahim', 'Teacher', 'Mathematics', '07030000003'),
('STF004', 'Malama Maryam Sani', 'Teacher', 'English', '08120000004'),
('STF005', 'Mr. Bashir Ahmed', 'Teacher', 'Basic Science', '08090000005'),
('STF006', 'Mrs. Rabi''u Fatima', 'Teacher', 'Islamic Studies', '07010000006')
ON CONFLICT (staff_id) DO NOTHING;

INSERT INTO notices (title, body, is_urgent, published_by) VALUES
('End of Term Examination Timetable Released', 'Exams begin 1st September. Collect timetable from class teachers.', true, 'Admin'),
('PTA Meeting – All Parents Invited', 'Saturday 30th August, 10:00 AM at the school hall.', false, 'Admin'),
('School Fees Reminder – 2nd Term', 'Outstanding fees should be cleared before report card collection.', true, 'Accounts'),
('New Junior Secondary Section Opening Soon', 'Application for JSS 1–3 ongoing. Contact the admin office.', false, 'Admin');

INSERT INTO fee_payments (student_name, class_name, term, total_amount, amount_paid, balance, payment_mode) VALUES
('Amina Yusuf', 'PRI 4', '2nd', 25000, 25000, 0, 'Cash'),
('Ibrahim Musa', 'PRI 5', '2nd', 25000, 15000, 10000, 'Transfer'),
('Fatima Abubakar', 'JS 1', '2nd', 30000, 30000, 0, 'POS'),
('Sani Mohammed', 'PRI 3', '2nd', 25000, 0, 25000, NULL),
('Hauwa Aliyu', 'PRI 6', '2nd', 25000, 25000, 0, 'Cash');


-- Class results entry (one row per student per term)
CREATE TABLE IF NOT EXISTS class_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  admission_no TEXT,
  student_name TEXT NOT NULL,
  class_name TEXT NOT NULL,
  term TEXT NOT NULL,
  session_year TEXT DEFAULT '2025/2026',
  english NUMERIC(5,1) DEFAULT 0,
  maths NUMERIC(5,1) DEFAULT 0,
  science NUMERIC(5,1) DEFAULT 0,
  social NUMERIC(5,1) DEFAULT 0,
  islamic_crs NUMERIC(5,1) DEFAULT 0,
  hausa NUMERIC(5,1) DEFAULT 0,
  computer NUMERIC(5,1) DEFAULT 0,
  total NUMERIC(6,1) DEFAULT 0,
  average NUMERIC(5,2) DEFAULT 0,
  grade TEXT,
  position INT,
  entered_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(admission_no, class_name, term, session_year)
);

ALTER TABLE class_results ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all on class_results" ON class_results FOR ALL USING (true) WITH CHECK (true);
