# Ismail Ahmad Memorial Academy — School Management System

**Website designed & developed by**  
**NA ALKALI ICT AND NETWORK SOLUTION CENTER**  
All Rights Reserved © 2026

---

## School Information

| | |
|---|---|
| **School** | Ismail Ahmad Memorial Academy |
| **Motto** | Knowledge & Progress |
| **Address** | Women Centre, Tsohon Layi, Jahun LGA, Jigawa State |
| **Email** | ismailahmadacademic@yahoo.com |
| **Website** | https://ismailahmadacademic.ng |
| **Phone** | 0907 810 3435 · 0803 664 4211 · 0703 831 3471 |
| **Levels** | Nursery · Primary (PRI 1–6) · Junior Secondary (JS 1–3) |

---

## Features

- Dashboard (stats, calendar, notices)
- Student management & search
- Daily attendance (Present / Late / Absent)
- Fees & payment recording
- **Enter Marks (Class Master only)**
- Auto **Average**, **Grade**, and **Position**
- **Dense ranking** (ties share position — no skip: 1,1,1 → 2 → 3…)
- Class result sheet & student report card (printable)
- Timetable, staff directory, notices
- Online admission form
- Supabase cloud database support
- Mobile responsive design

### Grading scale
| Grade | Average |
|-------|---------|
| A | 70 and above |
| B | 60 – 69 |
| C | 50 – 59 |
| D | 40 – 49 |
| E | 30 – 39 |
| F | Below 30 |

### Position (dense rank)
If four students score the same highest total → positions **1, 1, 1, 1**  
Next group → **2, 2…**  
Then **3**, and so on to the last student. Positions are **not skipped**.

---

## How to run

### Option A — Open directly
1. Download / clone this repository  
2. Open `index.html` in Chrome, Edge, or Firefox  

### Option B — Local server
```bash
cd school-website
python3 -m http.server 8080
```
Visit: http://localhost:8080

### Login (demo)
- Username: any (e.g. `admin` or `classmaster`)  
- Password: any  

For **Enter Marks**, select role **Class Master**.

---

## Supabase setup (optional cloud)

1. Project URL is already set in `js/supabase-config.js`  
2. Open Supabase → **SQL Editor**  
3. Run the full script in `supabase-schema.sql`  
4. Reload the website — top bar shows **Cloud connected** when successful  

---

## Project structure

```
school-website/
├── index.html              # Main application
├── css/
│   └── style.css           # Styles
├── js/
│   ├── app.js              # App logic + marks ranking
│   └── supabase-config.js  # Supabase keys
├── assets/
│   └── logo.jpg            # School logo
├── supabase-schema.sql     # Database tables
├── README.md
└── LICENSE
```

---

## Developer

**NA ALKALI ICT AND NETWORK SOLUTION CENTER**  
Web design · ICT · Network solutions  

**All Rights Reserved © 2026**

School portal built for Ismail Ahmad Memorial Academy, Jahun, Jigawa State.
